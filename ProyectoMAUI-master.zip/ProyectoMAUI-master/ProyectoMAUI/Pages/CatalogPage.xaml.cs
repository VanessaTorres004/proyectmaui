using Microsoft.Maui.Controls;
using ProyectoMAUI.Models;
using ProyectoMAUI.ViewModels;
using System.Collections.ObjectModel;

namespace ProyectoMAUI.Pages
{
    public partial class CatalogPage : ContentPage
    {
        public CatalogPage()
        {
            InitializeComponent();

            BindingContext = new CatalogPageViewModel();

        }

        private async void OnBuyClicked(object sender, EventArgs e)
        {
            var button = sender as Button;
            var productName = (button.BindingContext as Product)?.Name;
            await DisplayAlert("Compra", $"Has a�adido {productName} al carrito.", "OK");
            // Implementa l�gica adicional aqu�, si es necesario.
        }

        private ObservableCollection<CartItem> _cartItems = new ObservableCollection<CartItem>();

        private void OnProductBuyClicked(object sender, EventArgs e)
        {
            if (sender is Button button && button.BindingContext is Product product)
            {
                Navigation.PushAsync(new ProductDetailPage(product, _cartItems));
            }
        }
        private async void OnOpenFlyoutClicked(object sender, EventArgs e)
        {
            // Muestra el Flyout
            Shell.Current.FlyoutIsPresented = true;
        }





    }
}
